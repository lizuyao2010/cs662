#!/bin/sh

java -cp Chunker.jar mark.chunking.Chunker resources/rules resources/pos_tag_dict
